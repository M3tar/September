import json

data = '''
[
            {
                "category_id": "",
                "ins_id": "spa_85af1623-fc48-4ac5-9c4a-a597e9aa1c66",
                "is_enable": true,
                "os_type": "windows",
                "software_id": "soft_7188d276-8fbf-11ec-9927-0c42a131f786",
                "software_name": "Adobe Audition",
                "software_type": "设计剪辑类软件",
                "uid": ""
            },
            {
                "category_id": "",
                "ins_id": "spa_85af1623-fc48-4ac5-9c4a-a597e9aa1c66",
                "is_enable": true,
                "os_type": "windows",
                "software_id": "soft_7188d630-8fbf-11ec-9927-0c42a131f786",
                "software_name": "Adobe Bridge",
                "software_type": "设计剪辑类软件",
                "uid": ""
            },
            {
                "category_id": "",
                "ins_id": "spa_85af1623-fc48-4ac5-9c4a-a597e9aa1c66",
                "is_enable": true,
                "os_type": "windows",
                "software_id": "soft_7188d748-8fbf-11ec-9927-0c42a131f786",
                "software_name": "Adobe Photoshop",
                "software_type": "设计剪辑类软件",
                "uid": ""
            },
            {
                "category_id": "",
                "ins_id": "spa_85af1623-fc48-4ac5-9c4a-a597e9aa1c66",
                "is_enable": true,
                "os_type": "windows",
                "software_id": "soft_7188d8ab-8fbf-11ec-9927-0c42a131f786",
                "software_name": "Adobe Dreamweaver",
                "software_type": "设计剪辑类软件",
                "uid": ""
            },
            {
                "category_id": "",
                "ins_id": "spa_85af1623-fc48-4ac5-9c4a-a597e9aa1c66",
                "is_enable": true,
                "os_type": "windows",
                "software_id": "soft_7188d8ef-8fbf-11ec-9927-0c42a131f786",
                "software_name": "Adobe Illustrator",
                "software_type": "设计剪辑类软件",
                "uid": ""
            },
            {
                "category_id": "",
                "ins_id": "spa_85af1623-fc48-4ac5-9c4a-a597e9aa1c66",
                "is_enable": true,
                "os_type": "windows",
                "software_id": "soft_7188d928-8fbf-11ec-9927-0c42a131f786",
                "software_name": "Adobe Lightroom",
                "software_type": "设计剪辑类软件",
                "uid": ""
            },
            {
                "category_id": "",
                "ins_id": "spa_85af1623-fc48-4ac5-9c4a-a597e9aa1c66",
                "is_enable": true,
                "os_type": "windows",
                "software_id": "soft_7188d963-8fbf-11ec-9927-0c42a131f786",
                "software_name": "Adobe Premiere",
                "software_type": "设计剪辑类软件",
                "uid": ""
            },
            {
                "category_id": "",
                "ins_id": "spa_85af1623-fc48-4ac5-9c4a-a597e9aa1c66",
                "is_enable": true,
                "os_type": "windows",
                "software_id": "soft_7188dd1d-8fbf-11ec-9927-0c42a131f786",
                "software_name": "CLion",
                "software_type": "编程类软件",
                "uid": ""
            },
            {
                "category_id": "",
                "ins_id": "spa_85af1623-fc48-4ac5-9c4a-a597e9aa1c66",
                "is_enable": true,
                "os_type": "windows",
                "software_id": "soft_7188dd93-8fbf-11ec-9927-0c42a131f786",
                "software_name": "DataGrip",
                "software_type": "编程类软件",
                "uid": ""
            },
            {
                "category_id": "",
                "ins_id": "spa_85af1623-fc48-4ac5-9c4a-a597e9aa1c66",
                "is_enable": true,
                "os_type": "windows",
                "software_id": "soft_7188e168-8fbf-11ec-9927-0c42a131f786",
                "software_name": "GoLand",
                "software_type": "编程类软件",
                "uid": ""
            },
            {
                "category_id": "",
                "ins_id": "spa_85af1623-fc48-4ac5-9c4a-a597e9aa1c66",
                "is_enable": true,
                "os_type": "windows",
                "software_id": "soft_7188ee0b-8fbf-11ec-9927-0c42a131f786",
                "software_name": "PremiumSoft Navicat",
                "software_type": "编程类软件",
                "uid": ""
            },
            {
                "category_id": "",
                "ins_id": "spa_85af1623-fc48-4ac5-9c4a-a597e9aa1c66",
                "is_enable": true,
                "os_type": "windows",
                "software_id": "soft_7188ef03-8fbf-11ec-9927-0c42a131f786",
                "software_name": "pycharm",
                "software_type": "编程类软件",
                "uid": ""
            },
            {
                "category_id": "",
                "ins_id": "spa_85af1623-fc48-4ac5-9c4a-a597e9aa1c66",
                "is_enable": true,
                "os_type": "windows",
                "software_id": "soft_7188f68b-8fbf-11ec-9927-0c42a131f786",
                "software_name": "SecureCRT",
                "software_type": "编程类软件",
                "uid": ""
            },
            {
                "category_id": "",
                "ins_id": "spa_85af1623-fc48-4ac5-9c4a-a597e9aa1c66",
                "is_enable": true,
                "os_type": "windows",
                "software_id": "soft_7188f927-8fbf-11ec-9927-0c42a131f786",
                "software_name": "VMware Workstation",
                "software_type": "行业特色类软件",
                "uid": ""
            },
            {
                "category_id": "",
                "ins_id": "spa_85af1623-fc48-4ac5-9c4a-a597e9aa1c66",
                "is_enable": true,
                "os_type": "windows",
                "software_id": "soft_7188fac7-8fbf-11ec-9927-0c42a131f786",
                "software_name": "Windows",
                "software_type": "系统工具类软件",
                "uid": ""
            },
            {
                "category_id": "",
                "ins_id": "spa_85af1623-fc48-4ac5-9c4a-a597e9aa1c66",
                "is_enable": true,
                "os_type": "windows",
                "software_id": "soft_7188fb4f-8fbf-11ec-9927-0c42a131f786",
                "software_name": "WinRaR",
                "software_type": "助手类软件",
                "uid": ""
            },
            {
                "category_id": "",
                "ins_id": "spa_85af1623-fc48-4ac5-9c4a-a597e9aa1c66",
                "is_enable": true,
                "os_type": "windows",
                "software_id": "soft_7188fcb9-8fbf-11ec-9927-0c42a131f786",
                "software_name": "Xmind",
                "software_type": "办公类软件",
                "uid": ""
            },
            {
                "category_id": "",
                "ins_id": "spa_85af1623-fc48-4ac5-9c4a-a597e9aa1c66",
                "is_enable": true,
                "os_type": "windows",
                "software_id": "soft_7188bb44-8fbf-11ec-9927-0c42a131f787",
                "software_name": "Microsoft Office",
                "software_type": "办公类软件",
                "uid": ""
            },
            {
                "category_id": "",
                "ins_id": "spa_85af1623-fc48-4ac5-9c4a-a597e9aa1c66",
                "is_enable": true,
                "os_type": "windows",
                "software_id": "soft_7188bb44-8fbf-11ec-9927-0c42a131f788",
                "software_name": "Axure RP",
                "software_type": "设计剪辑类软件",
                "uid": ""
            },
            {
                "category_id": "",
                "ins_id": "spa_85af1623-fc48-4ac5-9c4a-a597e9aa1c66",
                "is_enable": true,
                "os_type": "windows",
                "software_id": "soft_462ee6a6-90ca-11ec-afbf-3ec2131841fb",
                "software_name": "WebStorm",
                "software_type": "编程类软件",
                "uid": ""
            },
            {
                "category_id": "",
                "ins_id": "spa_85af1623-fc48-4ac5-9c4a-a597e9aa1c66",
                "is_enable": true,
                "os_type": "windows",
                "software_id": "soft_46355068-90ca-11ec-afbf-3ec2131841fb",
                "software_name": "RubyMine",
                "software_type": "编程类软件",
                "uid": ""
            },
            {
                "category_id": "",
                "ins_id": "spa_85af1623-fc48-4ac5-9c4a-a597e9aa1c66",
                "is_enable": true,
                "os_type": "windows",
                "software_id": "soft_463692ac-90ca-11ec-afbf-3ec2131841fb",
                "software_name": "Rider",
                "software_type": "编程类软件",
                "uid": ""
            },
            {
                "category_id": "",
                "ins_id": "spa_85af1623-fc48-4ac5-9c4a-a597e9aa1c66",
                "is_enable": true,
                "os_type": "windows",
                "software_id": "soft_b93cc53c-90ca-11ec-afbf-3ec2131841fb",
                "software_name": "PhpStorm",
                "software_type": "编程类软件",
                "uid": ""
            },
            {
                "category_id": "",
                "ins_id": "spa_85af1623-fc48-4ac5-9c4a-a597e9aa1c66",
                "is_enable": true,
                "os_type": "windows",
                "software_id": "soft_88ef2d93-7c26-480a-82e9-2c3bb46303c3",
                "software_name": "Sublime Text",
                "software_type": "编程类软件",
                "uid": ""
            },
            {
                "category_id": "",
                "ins_id": "spa_85af1623-fc48-4ac5-9c4a-a597e9aa1c66",
                "is_enable": true,
                "os_type": "windows",
                "software_id": "soft_1c375895-af71-4d67-b59c-9e6d0d6a242a",
                "software_name": "xftp",
                "software_type": "编程类软件",
                "uid": ""
            },
            {
                "category_id": "",
                "ins_id": "spa_85af1623-fc48-4ac5-9c4a-a597e9aa1c66",
                "is_enable": true,
                "os_type": "windows",
                "software_id": "soft_86000e02-678e-42d1-8a07-213aa953a5aa",
                "software_name": "Beyond Compare",
                "software_type": "助手类软件",
                "uid": ""
            },
            {
                "category_id": "",
                "ins_id": "spa_85af1623-fc48-4ac5-9c4a-a597e9aa1c66",
                "is_enable": true,
                "os_type": "windows",
                "software_id": "soft_23e32b5e-89a2-4652-8235-dc25517846b4",
                "software_name": "Microsoft Visio",
                "software_type": "办公类软件",
                "uid": ""
            },
            {
                "category_id": "",
                "ins_id": "spa_85af1623-fc48-4ac5-9c4a-a597e9aa1c66",
                "is_enable": true,
                "os_type": "windows",
                "software_id": "soft_8ca6a4c9-3515-469c-b50c-0c050c62f4c7",
                "software_name": "Adobe Acrobat DC",
                "software_type": "办公类软件",
                "uid": ""
            },
            {
                "category_id": "",
                "ins_id": "spa_85af1623-fc48-4ac5-9c4a-a597e9aa1c66",
                "is_enable": true,
                "os_type": "windows",
                "software_id": "soft_c6bbf527-e5a2-4cce-84e7-6363a9db7902",
                "software_name": "IntelliJ IDEA",
                "software_type": "编程类软件",
                "uid": ""
            },
            {
                "category_id": "",
                "ins_id": "spa_85af1623-fc48-4ac5-9c4a-a597e9aa1c66",
                "is_enable": true,
                "os_type": "windows",
                "software_id": "soft_edaa5174-17f2-4d26-bae0-554e7f8defab",
                "software_name": "Typora",
                "software_type": "办公类软件",
                "uid": ""
            },
            {
                "category_id": "",
                "ins_id": "spa_85af1623-fc48-4ac5-9c4a-a597e9aa1c66",
                "is_enable": true,
                "os_type": "windows",
                "software_id": "soft_510b0cae-6eaa-4067-a59d-f4d75da90f8e",
                "software_name": "UltraEdit",
                "software_type": "编程类软件",
                "uid": ""
            },
            {
                "category_id": "",
                "ins_id": "spa_85af1623-fc48-4ac5-9c4a-a597e9aa1c66",
                "is_enable": true,
                "os_type": "windows",
                "software_id": "soft_3728b09a-28e3-4bd4-9e5b-8e12c4d091cd",
                "software_name": "MATLAB",
                "software_type": "助手类软件",
                "uid": ""
            },
            {
                "category_id": "",
                "ins_id": "spa_85af1623-fc48-4ac5-9c4a-a597e9aa1c66",
                "is_enable": true,
                "os_type": "windows",
                "software_id": "soft_72ea1ca5-64da-43c1-ad85-2efe56ee5ebf",
                "software_name": "Autodesk AutoCAD",
                "software_type": "办公类软件",
                "uid": ""
            },
            {
                "category_id": "",
                "ins_id": "spa_85af1623-fc48-4ac5-9c4a-a597e9aa1c66",
                "is_enable": true,
                "os_type": "windows",
                "software_id": "soft_892cbbba-295c-43c2-ae11-e7cce63b2f2c",
                "software_name": "MAXON Cinema 4D",
                "software_type": "设计剪辑类软件",
                "uid": ""
            },
            {
                "category_id": "",
                "ins_id": "spa_85af1623-fc48-4ac5-9c4a-a597e9aa1c66",
                "is_enable": true,
                "os_type": "windows",
                "software_id": "soft_f1186042-96b7-4017-a06a-cb5616689778",
                "software_name": "StarUML",
                "software_type": "编程类软件",
                "uid": ""
            },
            {
                "category_id": "",
                "ins_id": "spa_85af1623-fc48-4ac5-9c4a-a597e9aa1c66",
                "is_enable": true,
                "os_type": "windows",
                "software_id": "soft_583adfe0-2085-4b5b-8f16-798f581a4868",
                "software_name": "SmartGit",
                "software_type": "助手类软件",
                "uid": ""
            },
            {
                "category_id": "",
                "ins_id": "spa_85af1623-fc48-4ac5-9c4a-a597e9aa1c66",
                "is_enable": true,
                "os_type": "windows",
                "software_id": "soft_ad341c0c-6288-4e72-a282-bfaed64c90a9",
                "software_name": "Unity",
                "software_type": "编程类软件",
                "uid": ""
            },
            {
                "category_id": "",
                "ins_id": "spa_85af1623-fc48-4ac5-9c4a-a597e9aa1c66",
                "is_enable": true,
                "os_type": "windows",
                "software_id": "soft_8bcb7a97-97a7-4c0b-b63e-1d9a780391d3",
                "software_name": "Fiddler Everywhere",
                "software_type": "助手类软件",
                "uid": ""
            },
            {
                "category_id": "",
                "ins_id": "spa_85af1623-fc48-4ac5-9c4a-a597e9aa1c66",
                "is_enable": true,
                "os_type": "windows",
                "software_id": "soft_ad17324c-6039-415b-b1f3-3ce54ab4d162",
                "software_name": "Xshell",
                "software_type": "系统工具类软件",
                "uid": ""
            },
            {
                "category_id": "",
                "ins_id": "spa_85af1623-fc48-4ac5-9c4a-a597e9aa1c66",
                "is_enable": true,
                "os_type": "windows",
                "software_id": "soft_ee5c8471-5cdd-43cf-9849-c6b563a958bc",
                "software_name": "KeyShot",
                "software_type": "设计剪辑类软件",
                "uid": ""
            },
            {
                "category_id": "",
                "ins_id": "spa_85af1623-fc48-4ac5-9c4a-a597e9aa1c66",
                "is_enable": true,
                "os_type": "windows",
                "software_id": "soft_26f714a5-c33e-45d3-b3e7-6d59f5cf6f9f",
                "software_name": "Autodesk 3ds Max",
                "software_type": "行业特色类软件",
                "uid": ""
            },
            {
                "category_id": "",
                "ins_id": "spa_85af1623-fc48-4ac5-9c4a-a597e9aa1c66",
                "is_enable": true,
                "os_type": "windows",
                "software_id": "soft_c0429690-5b38-485d-a281-05d7409f032d",
                "software_name": "Marvelous Designer",
                "software_type": "其他",
                "uid": ""
            },
            {
                "category_id": "",
                "ins_id": "spa_85af1623-fc48-4ac5-9c4a-a597e9aa1c66",
                "is_enable": true,
                "os_type": "windows",
                "software_id": "soft_48f92bfa-7279-42db-a526-4f6815990a07",
                "software_name": "Autodesk Maya",
                "software_type": "设计剪辑类软件",
                "uid": ""
            },
            {
                "category_id": "",
                "ins_id": "spa_85af1623-fc48-4ac5-9c4a-a597e9aa1c66",
                "is_enable": true,
                "os_type": "windows",
                "software_id": "soft_fb293639-de7b-49e1-ae12-21e8dd320f12",
                "software_name": "ZBrush",
                "software_type": "其他",
                "uid": ""
            },
            {
                "category_id": "",
                "ins_id": "spa_85af1623-fc48-4ac5-9c4a-a597e9aa1c66",
                "is_enable": true,
                "os_type": "windows",
                "software_id": "soft_af9b82b7-1e4f-4f7b-a6f2-85fa38baa988",
                "software_name": "Houdini",
                "software_type": "其他",
                "uid": ""
            },
            {
                "category_id": "",
                "ins_id": "spa_85af1623-fc48-4ac5-9c4a-a597e9aa1c66",
                "is_enable": true,
                "os_type": "windows",
                "software_id": "soft_67ccda5c-d81c-4962-98be-d03f446fdbda",
                "software_name": "Nuke",
                "software_type": "其他",
                "uid": ""
            },
            {
                "category_id": "",
                "ins_id": "spa_85af1623-fc48-4ac5-9c4a-a597e9aa1c66",
                "is_enable": true,
                "os_type": "windows",
                "software_id": "soft_bda96225-e114-4eaf-82b2-6950f06abb17",
                "software_name": "Microsoft Visual Studio",
                "software_type": "其他",
                "uid": ""
            },
            {
                "category_id": "",
                "ins_id": "spa_85af1623-fc48-4ac5-9c4a-a597e9aa1c66",
                "is_enable": true,
                "os_type": "windows",
                "software_id": "soft_95cf6ed0-b065-4962-ad56-0959a385bdc0",
                "software_name": "GraphPad Prism",
                "software_type": "其他",
                "uid": ""
            },
            {
                "category_id": "",
                "ins_id": "spa_85af1623-fc48-4ac5-9c4a-a597e9aa1c66",
                "is_enable": true,
                "os_type": "windows",
                "software_id": "soft_9458e05b-e8da-4acb-ba5e-4627879f8925",
                "software_name": "inSSIDer 4",
                "software_type": "其他",
                "uid": ""
            },
            {
                "category_id": "",
                "ins_id": "spa_85af1623-fc48-4ac5-9c4a-a597e9aa1c66",
                "is_enable": true,
                "os_type": "windows",
                "software_id": "soft_d72a5f99-763b-4e21-b3c0-b21be2b01dbe",
                "software_name": "Autodesk License Server",
                "software_type": "其他",
                "uid": ""
            }
        ]
'''

parsed_data = json.loads(data)

for obj in parsed_data:
    software_name = obj["software_name"]
    software_type = obj["software_type"]
    print("Software Name:", software_name)
    print("Software Type:", software_type)
    print()

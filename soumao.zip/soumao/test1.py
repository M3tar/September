import Crypto

a = 111001111010100010001011

b= Crypto.Util.number.long_to_bytes(a)



print b.decode('utf-8')
